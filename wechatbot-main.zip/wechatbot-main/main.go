package main

import (
	"github.com/869413421/wechatbot/bootstrap"
)

func main() {
	bootstrap.Run()
}
